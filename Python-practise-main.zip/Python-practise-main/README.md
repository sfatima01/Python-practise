# Python-practise
My daily python practice
